﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace EventApp
{
    public class Event
    {
        public int EventNumber { get; set; }
        public string Location { get; set; }
    }

    public class Program
    {
        static void Main(string[] args)
        {
            Event event1 = new Event { EventNumber = 1, Location = "Calgary\nTech Competition" };
            SerializeToFile(event1, "event.txt");
            Event event2 = DeserializeFromFile<Event>("event.txt");
            Console.WriteLine($"{event2.EventNumber}\n{event2.Location}");

            List<Event> events = new List<Event>
            {
                new Event { EventNumber = 1, Location = "Calgary" },
                new Event { EventNumber = 2, Location = "Vancouver" },
                new Event { EventNumber = 3, Location = "Toronto" },
                new Event { EventNumber = 4, Location = "Edmonton" },
            };
            SerializeToJsonFile(events, "events.json");
            List<Event> events2 = DeserializeFromJsonFile<List<Event>>("events.json");
            foreach (Event e in events2)
            {
                Console.WriteLine($"{e.EventNumber} {e.Location}");
            }

            ReadFromFile("Hackathon", "temp.txt");
        }

        static void SerializeToFile<T>(T obj, string path)
        {
            string json = JsonSerializer.Serialize(obj);
            File.WriteAllText(path, json);
        }

        static T DeserializeFromFile<T>(string path)
        {
            string json = File.ReadAllText(path);
            return JsonSerializer.Deserialize<T>(json);
        }

        static void SerializeToJsonFile<T>(T obj, string path)
        {
            string json = JsonSerializer.Serialize(obj);
            File.WriteAllText(path, json);
        }

        static void ReadFromFile(string text, string path)
        {
            File.WriteAllText(path, text);
            using (StreamReader reader = new StreamReader(path))
            {
                char firstChar = text[0];
                char middleChar = text[text.Length / 2];
                char lastChar = text[text.Length - 1];

                Console.WriteLine($"In Word: {text}");
                Console.WriteLine($"The First Character is: \"{firstChar}\"");
                Console.WriteLine($"The Middle Character is: \"{middleChar}\"");
                Console.WriteLine($"The Last Character is: \"{lastChar}\"");
            }
        }

        public static List<T> DeserializeFromJsonFile<T>(string path)
        {
            string json = File.ReadAllText(path);
            return JsonSerializer.Deserialize<List<T>>(json);
        }
    }
}
